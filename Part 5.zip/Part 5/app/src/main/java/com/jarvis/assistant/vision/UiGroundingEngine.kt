package com.jarvis.assistant.vision

import android.graphics.PointF
import android.graphics.Rect
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale
import kotlin.math.abs

/**
 * Structured representation of an interactive or visible UI element
 * extracted directly from the Android Accessibility Tree with exact pixel bounds.
 */
data class UiElementInfo(
    val id: Int,
    val text: String,
    val contentDescription: String,
    val className: String,
    val viewId: String,
    val bounds: Rect,
    val isClickable: Boolean,
    val isCheckable: Boolean,
    val isChecked: Boolean,
    val isEditable: Boolean,
    val isScrollable: Boolean
) {
    val center: PointF
        get() = PointF(bounds.exactCenterX(), bounds.exactCenterY())

    val primaryLabel: String
        get() = when {
            text.isNotBlank() -> text
            contentDescription.isNotBlank() -> contentDescription
            viewId.isNotBlank() -> viewId.substringAfterLast("/")
            else -> className.substringAfterLast(".")
        }

    fun isSwitchOrToggle(): Boolean {
        return isCheckable || className.contains("Switch", ignoreCase = true) ||
                className.contains("CheckBox", ignoreCase = true) ||
                className.contains("ToggleButton", ignoreCase = true)
    }

    val hasTextOrDesc: Boolean
        get() = text.isNotBlank() || contentDescription.isNotBlank()

    val isImageOrThumbnail: Boolean
        get() {
            val simpleClass = className.substringAfterLast(".").lowercase(Locale.ROOT)
            val simpleVid = viewId.substringAfterLast("/").lowercase(Locale.ROOT)
            val lbl = primaryLabel.lowercase(Locale.ROOT)

            val isImgClass = simpleClass.contains("image") || simpleClass.contains("photo") || simpleClass.contains("thumb") || simpleClass.contains("picture")
            val isImgVid = simpleVid.contains("thumb") || simpleVid.contains("image") || simpleVid.contains("photo") || simpleVid.contains("pic") || simpleVid.contains("icon_thumbnail")
            val isImgLabel = lbl.endsWith(".jpg") || lbl.endsWith(".jpeg") || lbl.endsWith(".png") || lbl.endsWith(".webp") ||
                    lbl.startsWith("img_") || lbl.startsWith("pxl_") || lbl.startsWith("photo") || lbl == "image" || lbl == "photo"

            return (isImgClass || isImgVid || isImgLabel) && bounds.width() >= 60 && bounds.height() >= 60
        }

    val isGenericContainer: Boolean
        get() {
            if (hasTextOrDesc) return false
            if (isImageOrThumbnail) return false
            val simple = className.substringAfterLast(".").lowercase(Locale.ROOT)
            return simple in GENERIC_CONTAINERS
        }

    companion object {
        val GENERIC_CONTAINERS = setOf(
            "framelayout", "linearlayout", "relativelayout", "viewgroup",
            "view", "viewpager", "recyclerview", "scrollview", "nestedscrollview",
            "cardview", "coordinatorlayout", "constraintlayout"
        )
    }
}

/**
 * Dual-Anchor UI Grounding Engine.
 * Traverses Android's native Accessibility hierarchy and maps high-level
 * visual intents and spoken targets directly to hardware-accurate pixel bounding boxes.
 */
class UiGroundingEngine {

    companion object {
        private const val TAG = "UiGroundingEngine"
    }

    /**
     * Extracts all interactive or descriptive elements currently visible on the screen.
     */
    fun scanScreen(root: AccessibilityNodeInfo?): List<UiElementInfo> {
        if (root == null) return emptyList()
        val elements = mutableListOf<UiElementInfo>()
        var nextId = 1

        fun traverse(node: AccessibilityNodeInfo) {
            val bounds = Rect()
            node.getBoundsInScreen(bounds)

            var text = node.text?.toString()?.trim() ?: ""
            var desc = node.contentDescription?.toString()?.trim() ?: ""
            val cls = node.className?.toString() ?: ""
            val vid = node.viewIdResourceName ?: ""
            val isClickable = node.isClickable || node.parent?.isClickable == true
            val isCheckable = node.isCheckable
            val isEditable = node.isEditable || cls.contains("EditText", ignoreCase = true)
            val isScrollable = node.isScrollable

            // If a clickable row/card has no direct text, extract combined text from its descendants
            if (text.isBlank() && desc.isBlank() && node.childCount > 0 && isClickable) {
                val childTexts = collectNodeText(node)
                if (childTexts.isNotEmpty()) {
                    text = childTexts.joinToString(" • ")
                }
            }

            // Filter out 0-sized or offscreen invisible elements
            val isVisible = bounds.width() > 5 && bounds.height() > 5

            val isInteractiveOrMeaningful = isVisible && (
                isClickable || isCheckable || isEditable || isScrollable ||
                text.isNotBlank() || desc.isNotBlank()
            )

            if (isInteractiveOrMeaningful) {
                elements.add(
                    UiElementInfo(
                        id = nextId++,
                        text = text,
                        contentDescription = desc,
                        className = cls,
                        viewId = vid,
                        bounds = bounds,
                        isClickable = isClickable,
                        isCheckable = isCheckable,
                        isChecked = node.isChecked,
                        isEditable = isEditable,
                        isScrollable = isScrollable
                    )
                )
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                traverse(child)
            }
        }

        try {
            traverse(root)
        } catch (e: Exception) {
            Log.e(TAG, "Error traversing accessibility tree: ${e.message}")
        }

        return elements
    }

    /**
     * Resolves the target element with 100% precision:
     * 1. If explicit element ID is supplied, finds that element.
     * 2. If target is a toggle/switch for a specific setting (e.g. "Wireless Debugging"),
     *    locates the label first and snaps to the adjacent switch on the same row.
     * 3. Performs fuzzy semantic match across text, content description, and view IDs.
     */
    fun findTargetElement(
        elements: List<UiElementInfo>,
        targetName: String,
        isToggleIntent: Boolean = false,
        elementId: Int? = null
    ): UiElementInfo? {
        if (elementId != null && elementId > 0) {
            elements.firstOrNull { it.id == elementId }?.let { return it }
        }

        val query = targetName.trim().lowercase(Locale.ROOT)
        if (query.isBlank()) return null

        val cleanQuery = query.replace("[^a-zA-Z0-9]".toRegex(), "")
        val strippedQuery = query
            .replace("\\b(channel|group|folder|chat|app|page|tab|telegram|whatsapp|file)\\b".toRegex(RegexOption.IGNORE_CASE), "")
            .trim()
        val cleanStrippedQuery = strippedQuery.replace("[^a-zA-Z0-9]".toRegex(), "")

        // Case 1: Toggle/Switch intent for a labeled item (e.g. "enable Wireless Debugging")
        if (isToggleIntent) {
            // Find the label element first
            val labelElement = elements.filter {
                val text = it.text.lowercase(Locale.ROOT)
                val desc = it.contentDescription.lowercase(Locale.ROOT)
                val cleanText = text.replace("[^a-zA-Z0-9]".toRegex(), "")
                text.contains(query) || desc.contains(query) || 
                (cleanQuery.isNotEmpty() && cleanText.contains(cleanQuery)) ||
                query.contains(text.takeIf { t -> t.length > 3 } ?: "____")
            }.minByOrNull {
                abs(it.primaryLabel.length - query.length)
            }

            if (labelElement != null) {
                val adjacentSwitch = elements.filter {
                    it.isSwitchOrToggle() &&
                    abs(it.bounds.centerY() - labelElement.bounds.centerY()) < 150 &&
                    it.bounds.centerX() >= labelElement.bounds.centerX()
                }.minByOrNull {
                    abs(it.bounds.centerY() - labelElement.bounds.centerY())
                }

                if (adjacentSwitch != null) {
                    Log.i(TAG, "Grounded toggle intent: matched adjacent switch ${adjacentSwitch.id} for label '${labelElement.text}'")
                    return adjacentSwitch
                }

                if (labelElement.isClickable || labelElement.isCheckable) {
                    return labelElement
                }
            }
        }

        // Case 2: Exact text or Normalized match (e.g. "TajimUddin" matches "Tajim Uddin")
        elements.firstOrNull {
            val text = it.text.lowercase(Locale.ROOT)
            val desc = it.contentDescription.lowercase(Locale.ROOT)
            val cleanText = text.replace("[^a-zA-Z0-9]".toRegex(), "")
            val cleanDesc = desc.replace("[^a-zA-Z0-9]".toRegex(), "")

            text == query || desc == query ||
            (cleanQuery.isNotEmpty() && (cleanText == cleanQuery || cleanDesc == cleanQuery)) ||
            (cleanStrippedQuery.isNotEmpty() && (cleanText == cleanStrippedQuery || cleanDesc == cleanStrippedQuery))
        }?.let { return it }

        // Case 3: Normalized Substring Containment (e.g. "tajim" inside "tajimuddin")
        elements.firstOrNull {
            val text = it.text.lowercase(Locale.ROOT)
            val desc = it.contentDescription.lowercase(Locale.ROOT)
            val cleanText = text.replace("[^a-zA-Z0-9]".toRegex(), "")
            val cleanDesc = desc.replace("[^a-zA-Z0-9]".toRegex(), "")

            (cleanQuery.length >= 3 && (cleanText.contains(cleanQuery) || cleanQuery.contains(cleanText.takeIf { t -> t.length >= 3 } ?: "____"))) ||
            (cleanStrippedQuery.length >= 3 && (cleanText.contains(cleanStrippedQuery) || cleanStrippedQuery.contains(cleanText.takeIf { t -> t.length >= 3 } ?: "____")))
        }?.let { return it }

        // Case 4: Token/Word Overlap (e.g. "Tajim Discussion" when searching "TajimUddin" or "Tajim")
        val queryTokens = query.split("\\s+".toRegex()).filter { it.length > 2 }
        if (queryTokens.isNotEmpty()) {
            val bestTokenMatch = elements.filter { el ->
                val elText = el.primaryLabel.lowercase(Locale.ROOT)
                queryTokens.any { token -> elText.contains(token) }
            }.maxByOrNull { el ->
                val elText = el.primaryLabel.lowercase(Locale.ROOT)
                queryTokens.count { token -> elText.contains(token) }
            }
            if (bestTokenMatch != null) {
                return bestTokenMatch
            }
        }

        // Case 5: Search input intent ("search", "find", "query")
        if (query.contains("search") || query.contains("type") || query.contains("find")) {
            elements.firstOrNull { it.isEditable }?.let { return it }
        }

        // Case 6: Spatial position or generic image matching (e.g. "image at top-center", "first photo", "photo at top right")
        val spatialTerms = listOf(
            "top-left", "top left", "top-center", "top center", "top-right", "top right",
            "mid-left", "mid left", "mid-center", "mid center", "mid-right", "mid right",
            "bottom-left", "bottom left", "bottom-center", "bottom center", "bottom-right", "bottom right"
        )
        val combinedText = "$query $cleanStrippedQuery".lowercase(Locale.ROOT)
        for (spatial in spatialTerms) {
            if (combinedText.contains(spatial)) {
                val normSpatial = spatial.replace(" ", "-")
                val matched = elements.filter { it.isImageOrThumbnail }.firstOrNull { el ->
                    val elSpatial = getSpatialPosition(el.bounds, 1080, 2400).lowercase(Locale.ROOT)
                    elSpatial == normSpatial
                }
                if (matched != null) return matched
            }
        }

        if (query == "image" || query == "photo" || query == "thumbnail" || query == "picture" ||
            query.contains("first photo") || query.contains("first image")) {
            elements.firstOrNull { it.isImageOrThumbnail }?.let { return it }
        }

        return null
    }

    fun extractScreenContext(root: AccessibilityNodeInfo?, elements: List<UiElementInfo>): Pair<String, String> {
        val pkg = root?.packageName?.toString() ?: ""
        val titleCandidate = elements
            .filter { it.text.isNotBlank() && it.bounds.top in 60..380 && it.bounds.height() in 20..220 && it.text.length in 3..60 }
            .minByOrNull { it.bounds.top }
            ?.text ?: ""
        return Pair(pkg, titleCandidate)
    }

    private fun collectNodeText(node: AccessibilityNodeInfo, depth: Int = 0): List<String> {
        if (depth > 3) return emptyList()
        val list = mutableListOf<String>()
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val ct = child.text?.toString()?.trim() ?: child.contentDescription?.toString()?.trim() ?: ""
            if (ct.isNotBlank() && !list.contains(ct)) {
                list.add(ct)
            }
            if (child.childCount > 0) {
                list.addAll(collectNodeText(child, depth + 1))
            }
        }
        return list
    }

    fun getSpatialPosition(bounds: Rect, screenWidth: Int, screenHeight: Int): String {
        val cx = bounds.centerX()
        val cy = bounds.centerY()

        val vPos = when {
            cy < screenHeight * 0.35f -> "Top"
            cy < screenHeight * 0.65f -> "Mid"
            else -> "Bottom"
        }

        val hPos = when {
            cx < screenWidth * 0.33f -> "Left"
            cx < screenWidth * 0.67f -> "Center"
            else -> "Right"
        }

        return "$vPos-$hPos"
    }

    /**
     * Compact summary of visible interactive elements to attach to prompt or context.
     */
    fun formatElementsSummary(elements: List<UiElementInfo>, root: AccessibilityNodeInfo? = null): String {
        val sb = StringBuilder()
        val (pkg, title) = extractScreenContext(root, elements)
        if (pkg.isNotBlank()) sb.append("App: $pkg | ")
        if (title.isNotBlank()) sb.append("Screen Title: \"$title\"\n") else if (pkg.isNotBlank()) sb.append("\n")

        sb.append("Visible Elements:\n")
        val meaningful = elements.filter {
            (it.text.isNotBlank() || it.contentDescription.isNotBlank() || it.isEditable || it.isCheckable || (it.isClickable && it.isImageOrThumbnail)) &&
            !it.isGenericContainer
        }

        val screenBounds = Rect()
        root?.getBoundsInScreen(screenBounds)
        val screenWidth = if (screenBounds.width() > 0) screenBounds.width() else elements.maxOfOrNull { it.bounds.right } ?: 1080
        val screenHeight = if (screenBounds.height() > 0) screenBounds.height() else elements.maxOfOrNull { it.bounds.bottom } ?: 2400

        for (el in meaningful.take(75)) {
            val label = if (el.isImageOrThumbnail && (el.primaryLabel.isBlank() || el.primaryLabel.contains("ImageView", ignoreCase = true))) {
                "Image Thumbnail"
            } else {
                el.primaryLabel
            }

            sb.append("[#${el.id}] $label")
            if (el.isSwitchOrToggle()) {
                sb.append(" (Switch: ${if (el.isChecked) "ON" else "OFF"})")
            } else if (el.isEditable) {
                sb.append(" (InputField)")
            } else if (el.isImageOrThumbnail) {
                val spatial = getSpatialPosition(el.bounds, screenWidth, screenHeight)
                sb.append(" (Position: $spatial, bounds=[${el.bounds.left},${el.bounds.top},${el.bounds.right},${el.bounds.bottom}])")
            }
            sb.append("\n")
        }
        return sb.toString().trim()
    }
}
